<?php 
  error_reporting(0);
  $maxResultsPerPage = 10;
  
  
  $local = true;
  if($local){
    $baseURL='local.efx.42web.io';
    $baseAssetsURL = 'https://local.assets.twilightparadox.com';
  }else{
    $baseURL='efx.42web.io';
    $baseAssetsURL = 'https://assets.twilightparadox.com';
  }
  
  $req = ltrim($_SERVER['REQUEST_URI'],'/');
  $_GET['i'] = '';
  if(strlen($req) && !file_exists($req)){
    $_GET['i'] = $req;
  }
  if(strpos('?i=',$_GET['i'])!=false){
    $_GET['i'] = explode('?i=',$_GET['i'])[1];
  }


  //$db_user  = 'id21269596_user';
  //$db_user  = 'if0_35686192';
  //$db_user  = 'id21257390_user';
  //$db_user  = 'id21552617_user';
  //$db_user  = 'id21553412_user';
  $db_user  = 'if0_35686192';
  $db_pass  = 'iOFWM03Om1SRTI';
  $db_host  = 'sql106.infinityfree.com';
  //$db       = "id21269596_videodemos";
  //$db       = "if0_35686192_arena";
  //$db       = "id21257390_default";
  //$db       = "id21552617_orbs2";
  //$db       = "id21553412_orbs3";
  $db       = "if0_35686192_arena";
  $port     = '3306';
  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);
  $baseURL  = "https://efx.42web.io/b";
  $baseFullURL= ($local ? 'https://' : 'https://') . $baseURL;
?>
