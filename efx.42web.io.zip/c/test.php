<?php
  $s = explode('/', "?i=/post/2w7m");
  echo $s[1] . "\n";
?>
