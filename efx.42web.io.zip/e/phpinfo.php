<?php 
require('db.php');
phpinfo();
?>
