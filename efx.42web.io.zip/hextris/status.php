<?php

  //ini_set('display_errors', 0);
  //ini_set('display_startup_errors', 0);
  error_reporting(0);
  //error_reporting(E_ERROR | E_PARSE);
  $db_pass  = 'iOFWM03Om1SRTI';
  $port     = '3306';
  $db_host  = 'sql106.infinityfree.com';

  $db = $_GET['db'];
  $db_user = $_GET['user'];

  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);

  $sql = 'SELECT * FROM hextrisSessions';
  $res = mysqli_query($link, $sql);
  echo json_encode([!!mysqli_num_rows($res)]);
?>
