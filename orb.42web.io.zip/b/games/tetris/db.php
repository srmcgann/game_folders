<?php
  //$db_user  = 'id21269596_user';
  $db_user  = 'if0_35680488';
  //$db_user  = 'id21257390_user';
  //$db_user  = 'id21552617_user';
  //$db_user  = 'id21553412_user';
  //$db_user  = 'id21583283_user';
  $db_pass  = '9K12EE4mmF3yi';
  $db_host  = 'sql213.infinityfree.com';
  //$db       = "id21269596_videodemos";
  $db       = "if0_35680488_arena";
  //$db       = "id21257390_default";
  //$db       = "id21552617_orbs2";
  //$db       = "id21553412_orbs3";
  //$db       = "id21583283_orbs4";
  $port     = '3306';
  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);
?>
