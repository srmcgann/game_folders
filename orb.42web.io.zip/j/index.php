<?php 
  echo 'assets root folder. nothing to see here!';
?>
