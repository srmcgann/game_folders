<?php
  error_reporting(E_ALL);
  $db_user  = 'id21552617_user';
  $db_pass  = '9K12EE4mmF3yi';
  $db_host  = 'sql213.infinityfree.com';
  $db       = "id21552617_orbs2";
  $port     = '3306';
  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);
  
  $sql = "SELECT * FROM orbsMirrors";
  $res = mysqli_query($link, $sql);
  for($i=0; $i<mysqli_num_rows($res); ++$i){
    $row = mysqli_fetch_assoc($res);
    $db = $row['cred'];
    $user = $row['user'];
    $pass = '9K12EE4mmF3yi';
    $port = 3306;
    $host = 'sql213.infinityfree.com';
    $link2 = mysqli_connect($host, $user, $pass, $db, $port);
    $sql = "UPDATE orbsMirrors SET active = 0 WHERE id = 7";
    mysqli_query($link2, $sql);
    mysqli_close($link2);
    echo 'setting id:' . $row['id'] . '<br>';
  }
  echo "<br><br>done."
?>
