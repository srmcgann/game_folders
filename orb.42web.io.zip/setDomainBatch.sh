#!/bin/bash

php sd.php "$1" "$2" "$3" "$4" "$5";
