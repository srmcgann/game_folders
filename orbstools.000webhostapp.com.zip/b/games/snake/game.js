function loadMaps(){
	
	maps=new Array();
	maps.push("[[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]]");
	maps.push("[[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,2,2,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,2,2,2,2,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,2,2,2,2,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,2,2,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,2,2,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,2,2,2,2,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,2,2,2,2,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,2,2,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,2,2,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,2,2,2,2,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,2,2,2,2,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,2,2,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]]");
	maps.push("[[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,2,2,2,2,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,2,2,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,2,2,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,2,2,2,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,2,2,2,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,2,2,2,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,2,2,2,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,2,2,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,2,2,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]]");
	maps.push("[[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,2,2,2,2,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,2,2,2,2,1,1,1,1,1,1,2],[2,1,1,1,1,1,2,2,2,2,2,2,1,1,1,1,1,2],[2,1,1,1,1,1,2,2,2,2,2,2,1,1,1,1,1,2],[2,1,1,1,1,1,1,2,2,2,2,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,2,2,2,2,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]]");
	maps.push("[[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,2,2,1,1,2,2,1,1,1,1,1,2],[2,1,1,1,1,2,2,1,1,1,1,2,2,1,1,1,1,2],[2,1,1,1,2,2,1,1,1,1,1,1,2,2,1,1,1,2],[2,1,1,2,2,1,1,1,1,1,1,1,1,2,2,1,1,2],[2,1,1,2,1,1,1,1,1,1,1,1,1,1,2,1,1,2],[2,1,1,2,1,1,1,1,1,1,1,1,1,1,2,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,2,1,1,1,1,1,1,1,1,1,1,2,1,1,2],[2,1,1,2,1,1,1,1,1,1,1,1,1,1,2,1,1,2],[2,1,1,2,2,1,1,1,1,1,1,1,1,2,2,1,1,2],[2,1,1,1,2,2,1,1,1,1,1,1,2,2,1,1,1,2],[2,1,1,1,1,2,2,1,1,1,1,2,2,1,1,1,1,2],[2,1,1,1,1,1,2,2,1,1,2,2,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]]");
	maps.push("[[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,2],[2,2,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,2],[2,2,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2],[2,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2],[2,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,2],[2,2,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,2],[2,2,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]]");
	maps.push("[[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,2,2,2,2,2,1,1,1,1,1,1,2,2,2,2,2,2],[2,2,2,2,2,2,1,1,1,1,1,1,2,2,2,2,2,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]]");
	maps.push("[[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,2,2,2,2,2,2,2,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,2,2,2,2,2,2,2,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]]");
	maps.push("[[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,2,2,2,1,1,1,1,2,2,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,2,2,2,2,2,2,2,2,2,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,2,2,2,2,2,2,2,2,2,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,2,2,1,1,1,1,2,2,2,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]]");
	maps.push("[[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,2,2,2,2,2,2,1,1,1,1,1,2],[2,1,1,1,1,1,2,1,1,1,1,2,1,1,1,1,1,2],[2,1,1,1,1,1,2,1,1,1,1,2,1,1,1,1,1,2],[2,1,1,1,1,1,2,1,1,1,1,2,1,1,1,1,1,2],[2,1,1,1,1,1,2,1,1,1,1,2,1,1,1,1,1,2],[2,1,1,1,1,1,2,1,1,1,1,2,1,1,1,1,1,2],[2,1,1,1,1,1,2,1,1,1,1,2,1,1,1,1,1,2],[2,1,1,1,1,1,2,1,1,1,1,2,1,1,1,1,1,2],[2,1,1,1,1,1,2,1,1,1,1,2,1,1,1,1,1,2],[2,1,1,1,1,1,2,1,1,1,1,2,1,1,1,1,1,2],[2,1,1,1,1,1,2,1,1,1,1,2,1,1,1,1,1,2],[2,1,1,1,1,1,2,1,1,1,1,2,1,1,1,1,1,2],[2,1,1,1,1,1,2,1,1,1,1,2,1,1,1,1,1,2],[2,1,1,1,1,2,2,1,1,1,1,2,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,2],[2,1,1,1,2,2,1,1,1,1,1,1,2,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2],[2,1,1,2,2,1,1,1,1,1,1,1,1,2,2,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2],[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]]");
}

/*
	direction
	   0
	   |
	3--+--1
	   |
	   2
*/

function loadLevel(showIntro){

	map = $.parseJSON(maps[level-1]);
	color0="#000";
	alive=true;
	deathScreenAlpha=0;
	moveTimer=0;
	grow=0;
	goalsEaten=0;
	snake=new Array();
	if(showIntro)introScreenAlpha=1;
	switch(level){
		case 1:
			point=new Object();
			point.x=cols/4;
			point.y=rows/2;
			snake.push(point);
			point=new Object();
			point.x=cols/4-1;
			point.y=rows/2;
			snake.push(point);
			direction=1;
			snakeSpeed=7;
			goalsToAdvance=10;
			break;
		case 2:
			point=new Object();
			point.x=cols/4;
			point.y=rows/2;
			snake.push(point);
			point=new Object();
			point.x=cols/4-1;
			point.y=rows/2;
			snake.push(point);
			direction=1;
			snakeSpeed=7;
			goalsToAdvance=11;
			break;
		case 3:
			point=new Object();
			point.x=cols/4;
			point.y=rows-4;
			snake.push(point);
			point=new Object();
			point.x=cols/4-1;
			point.y=rows-4;
			snake.push(point);
			direction=1;
			snakeSpeed=6;
			goalsToAdvance=12;
			break;
		case 4:
			point=new Object();
			point.x=parseInt(cols*.75);
			point.y=parseInt(rows/4);
			snake.push(point);
			point=new Object();
			point.x=parseInt(cols*.75)+1;
			point.y=parseInt(rows/4);
			snake.push(point);
			direction=3;
			snakeSpeed=6;
			goalsToAdvance=13;
			break;
		case 5:
			point=new Object();
			point.x=cols/4;
			point.y=rows/2;
			snake.push(point);
			point=new Object();
			point.x=cols/4-1;
			point.y=rows/2;
			snake.push(point);
			direction=1;
			snakeSpeed=5;
			goalsToAdvance=14;
			break;
		case 6:
			point=new Object();
			point.x=cols/4-5;
			point.y=rows/2-4;
			snake.push(point);
			point=new Object();
			point.x=cols/4-5;
			point.y=rows/2-5;
			snake.push(point);
			direction=2;
			snakeSpeed=5;
			goalsToAdvance=15;
			break;
		case 7:
			point=new Object();
			point.x=parseInt(cols/6);
			point.y=rows/2+2;
			snake.push(point);
			point=new Object();
			point.x=parseInt(cols/6)-1;
			point.y=rows/2+2;
			snake.push(point);
			direction=1;
			snakeSpeed=5;
			goalsToAdvance=13;
			break;
		case 8:
			point=new Object();
			point.x=cols/4;
			point.y=rows/2;
			snake.push(point);
			point=new Object();
			point.x=cols/4-1;
			point.y=rows/2;
			snake.push(point);
			direction=1;
			snakeSpeed=4;
			goalsToAdvance=14;
			break;
		case 9:
			point=new Object();
			point.x=cols/4-3;
			point.y=rows/2+6;
			snake.push(point);
			point=new Object();
			point.x=cols/4-4;
			point.y=rows/2+6;
			snake.push(point);
			direction=1;
			snakeSpeed=4;
			goalsToAdvance=15;
			break;
		case 10:
			point=new Object();
			point.x=cols/4-3;
			point.y=rows/2+6;
			snake.push(point);
			point=new Object();
			point.x=cols/4-4;
			point.y=rows/2+6;
			snake.push(point);
			direction=1;
			snakeSpeed=3;
			goalsToAdvance=12;
			break;
	}
	spawnGoal();
	oldDirection=direction;
}

function initVars(){
	
	pi=Math.PI;
	canvas=$("#canvas")[0];
	ctx=canvas.getContext("2d");
	frames=0;
	canvas.width=1360;
	canvas.height=768;
	cx=canvas.width/2;
	cy=canvas.height/2;
	atlas=new Image();
	atlas.src="Textures.png";
	atlas.onload=function(){
		width=atlas.width/7;
		height=atlas.height/2;		
	};
	startScreen=new Image();
	startScreen.src="StartScreen.png";
	deathScreen=new Image();
	deathScreen.src="LoseScreen.png";
	victoryScreen=new Image();
	victoryScreen.src="WinScreen.png";
	victoryScreenAlpha=0;
	vignette=new Image();
	vignette.src="Vignette.png";
	chuckNorris=new Image();
	chuckNorris.src="chuckNorris.png";
	soundtrack=new Audio();
	soundtrack.addEventListener('ended', function() {
		this.currentTime = 0;
		this.play();
	}, false);
	goalSound=new Audio("goal.ogg");
	goalSound.volume=.4;
	deathSound=new Audio("death.ogg");
	deathSound.volume=.3;
	leftkey=rightkey=upkey=downkey=spacekey=enterkey=wkey=akey=skey=dkey=0;
	mx=my=leftButton=rightButton=0;
	level=1;
	map = $.parseJSON(maps[level-1]);
	rows=map[0].length;
	cols=map.length;
	size=cx*2/cols;
	score=0;
	canvas.addEventListener("mousemove", mouse, true);
	canvas.onmousedown=function(event){event.preventDefault();}
	canvas.addEventListener("mousedown", function(event) {
		switch (event.which) {
			case 1: leftButton=true; break;
			case 3: rightButton=true; break;
		}
	});
	canvas.addEventListener("mouseup", function(event) {
		switch (event.which) {
			case 1: leftButton=false; break;
			case 3: rightButton=false; break;
		}
	});
}

function mouse(e) {

    var rect = canvas.getBoundingClientRect();
	mx = Math.round((e.clientX-rect.left)/(rect.right-rect.left)*canvas.width);
	my = Math.round((e.clientY-rect.top)/(rect.bottom-rect.top)*canvas.height);
}

window.addEventListener("keydown", function(e){
	chr=e.keyCode || e.charCode;
	switch(chr){
		case 37:
			leftkey=1;
			if(direction!=1){
				oldDirection=-1;
				direction=3;
			}
			if(!victoryScreenAlpha&&!deathScreenAlpha)doLogic();
			break;
		case 38:
			upkey=1;
			if(direction!=2){
				oldDirection=-1;
				direction=0;
			}
			if(!victoryScreenAlpha&&!deathScreenAlpha)doLogic();
			break;
		case 39:
			rightkey=1;
			if(direction!=3){
				oldDirection=-1;
				direction=1;
			}
			if(!victoryScreenAlpha&&!deathScreenAlpha)doLogic();
			break;
		case 40:
			downkey=1;
			if(direction!=0){
				oldDirection=-1;
				direction=2;
			}
			if(!victoryScreenAlpha&&!deathScreenAlpha)doLogic();
			break;
		case 32:spacekey=1;break;
		case 13:enterkey=1;break;
	}
});

window.addEventListener("keyup", function(e){
	chr=e.keyCode || e.charCode;
	switch(chr){
		case 37:leftkey=0;break;
		case 38:upkey=0;break;
		case 39:rightkey=0;break;
		case 40:downkey=0;break;
		case 32:spacekey=0;break;
		case 13:enterkey=0;break;
	}
});

function emptyGrid(){
	
	grid=new Array(cols);
	for(k=0;k<cols;++k){
		grid[k]=new Array(rows);
		for(k2=0;k2<rows;++k2) grid[k][k2]=0;
	}
	return grid;
}

function rgb(col){
	
	var r = parseInt((.5+Math.sin(col)*.5)*16);
	var g = parseInt((.5+Math.cos(col)*.5)*16);
	var b = parseInt((.5-Math.sin(col)*.5)*16);
	return "#"+r.toString(16)+g.toString(16)+b.toString(16);
}

function spawnGoal(){
	
	goal=new Object();
	do{
		occupied=false;
		goal.x=Math.floor(Math.random()*cols);
		goal.y=Math.floor(Math.random()*rows);
		if(map[goal.x][goal.y]==2) occupied=true;
		for(k=0;k<snake.length;++k) if(snake[k].x==goal.x&&snake[k].y==goal.y)occupied=true;
	}while(occupied);
}

function doLogic(){


	if(goalsEaten>=goalsToAdvance){
		victoryScreenAlpha=.05;
		victoryUp=true;
	}else{
		if(moveTimer<frames||oldDirection!=direction){
			moveTimer=frames+snakeSpeed;
			point=new Object();
			switch(direction){
				case 0: point.x=snake[0].x; point.y=snake[0].y-1; break;
				case 1: point.x=snake[0].x+1; point.y=snake[0].y; break;
				case 2: point.x=snake[0].x; point.y=snake[0].y+1; break;
				case 3: point.x=snake[0].x-1; point.y=snake[0].y; break;
			}
			for(i=3;i<snake.length;++i){
				if(point.x==snake[i].x&&point.y==snake[i].y) alive=false;
			}
			if(map[point.x][point.y]==2) alive=false;
			if(alive){
				snake.splice(0,0,point);
				if(goal.x==snake[0].x&&goal.y==snake[0].y){
					if(goalsEaten<goalsToAdvance-1)spawnGoal();
					score+=100*level;
					goalSound=new Audio("goal.ogg");
					goalSound.volume=.4;
					goalSound.play();
					goalsEaten++;
					grow+=2;
				}else{
					if(grow>0){
						grow--;
					}else{
						snake.splice(snake.length-1,1);				
					}
				}
			}else{
				deathSound.play();
			}
		}
		oldDirection=direction;
	}
}

function drawRotatedImage(image, x, y, width, height, angle) { 

	ctx.save();
	ctx.translate(x, y);
	ctx.rotate(angle);
	ctx.drawImage(image, -width/2, -height/2, width, height);
	ctx.restore();
}

function addCommas(intNum) {

  return (intNum + '').replace(/(\d)(?=(\d{3})+$)/g, '$1,');
}

function drawSnake(){
	
	if(snake[1].y>snake[0].y) d=0;
	if(snake[1].x<snake[0].x) d=1;
	if(snake[1].y<snake[0].y) d=2;
	if(snake[1].x>snake[0].x) d=3;
	theta=pi*2/4*d-pi/2;
	stage=2;
	subX=atlas.width/7*(stage%7);
	subY=atlas.height/2*parseInt(stage/7);
	ctx.save();
	ctx.translate(snake[0].x*size+size/2, snake[0].y*size+size/2);
	ctx.rotate(theta);
	ctx.drawImage(atlas,subX,subY,width,height,-size/2,-size/2,size,size);
	ctx.restore();
	stage=4;
	for(i=1;i<snake.length-1;++i){
		if(snake[i-1].x>snake[i].x && snake[i].x>snake[i+1].x ||
		   snake[i-1].y>snake[i].y && snake[i].y>snake[i+1].y ||
		   snake[i-1].x<snake[i].x && snake[i].x<snake[i+1].x ||
		   snake[i-1].y<snake[i].y && snake[i].y<snake[i+1].y) stage=1;
		if(snake[i-1].x>snake[i].x && snake[i].y<snake[i+1].y) stage=7;
		if(snake[i-1].x<snake[i].x && snake[i].y<snake[i+1].y) stage=8;
		if(snake[i-1].x>snake[i].x && snake[i].y>snake[i+1].y) stage=9;
		if(snake[i-1].x<snake[i].x && snake[i].y>snake[i+1].y) stage=10;
		if(snake[i+1].x>snake[i].x && snake[i].y<snake[i-1].y) stage=7;
		if(snake[i+1].x<snake[i].x && snake[i].y<snake[i-1].y) stage=8;
		if(snake[i+1].x>snake[i].x && snake[i].y>snake[i-1].y) stage=9;
		if(snake[i+1].x<snake[i].x && snake[i].y>snake[i-1].y) stage=10;
		subX=atlas.width/7*(stage%7);
		subY=atlas.height/2*parseInt(stage/7)-1;
		ctx.drawImage(atlas,subX,subY,width,height,snake[i].x*size,snake[i].y*size,size,size);
	}

	if(snake[snake.length-2].y>snake[snake.length-1].y) d=0;
	if(snake[snake.length-2].x<snake[snake.length-1].x) d=1;
	if(snake[snake.length-2].y<snake[snake.length-1].y) d=2;
	if(snake[snake.length-2].x>snake[snake.length-1].x) d=3;
	theta=pi*2/4*d+pi/2;
	stage=0;
	subX=atlas.width/7*(stage%7);
	subY=atlas.height/2*parseInt(stage/7);
	ctx.save();
	ctx.translate(snake[snake.length-1].x*size+size/2,snake[snake.length-1].y*size+size/2);
	ctx.rotate(theta);
	ctx.drawImage(atlas,subX,subY,width,height,-size/2,-size/2,size,size);
	ctx.restore();
}

function draw(){
	
	ctx.clearRect(0,0,cx*2,cy*2);
	ctx.globalAlpha=1;	
	
	for(i=0;i<cols;++i){
		for(j=0;j<rows;++j){
			stage=map[i][j]==2?11:4;
			subX=1+atlas.width/7*(stage%7);
			subY=atlas.height/2*parseInt(stage/7);
			ctx.drawImage(atlas,subX,subY,width,height,i*size,j*size,size+1,size+1);
		}
	}
	for(i=0;i<cols;++i){
		for(j=0;j<rows;++j){
			if(map[i][j]==1){
				if(i>0&&map[i-1][j]==2){
					stage=12;
					subX=1+atlas.width/7*(stage%7);
					subY=atlas.height/2*parseInt(stage/7);
					ctx.drawImage(atlas,subX,subY,width,height,i*size,j*size,size+1,size+1);
				}
				if(j>0&&map[i][j-1]==2){
					stage=5;
					subX=1+atlas.width/7*(stage%7);
					subY=atlas.height/2*parseInt(stage/7);
					ctx.drawImage(atlas,subX,subY,width,height,i*size,j*size,size+1,size+1);					
				}
				if(i<cols-1&&map[i+1][j]==2){
					stage=6;
					subX=1+atlas.width/7*(stage%7);
					subY=atlas.height/2*parseInt(stage/7);
					ctx.drawImage(atlas,subX,subY,width,height,i*size,j*size,size+1,size+1);					
				}
				if(j<rows-1&&map[i][j+1]==2){
					stage=13;
					subX=1+atlas.width/7*(stage%7);
					subY=atlas.height/2*parseInt(stage/7);
					ctx.drawImage(atlas,subX,subY,width,height,i*size,j*size,size+1,size+1);					
				}
			}
		}
	}
	
	ctx.globalAlpha=1;
	stage=3;
	subX=1+atlas.width/7*(stage%7);
	subY=atlas.height/2*parseInt(stage/7)-1;
	ctx.drawImage(atlas,subX,subY,width,height, goal.x*size, goal.y*size, size, size);
	
	drawSnake();
	
	ctx.globalCompositeOperation="multiply";
	ctx.drawImage(vignette,0,0,cx*2,cy*2);
	ctx.globalCompositeOperation="source-over";
	
	ctx.globalAlpha=.5
	ctx.fillStyle="#0a8";
	ctx.strokeStyle="#fff";
	ctx.lineWidth=2;
	ctx.font="60px tahoma";
	ctx.fillText("Score: "+addCommas(score),10,65);
	ctx.strokeText("Score: "+addCommas(score),10,65);
	ctx.fillText("Level : "+level,10,125);
	ctx.strokeText("Level : "+level,10,125);

	ctx.textAlign="end";
	ctx.fillText("Remaining: "+(goalsToAdvance-goalsEaten),cx*2-20,65);
	ctx.strokeText("Remaining: "+(goalsToAdvance-goalsEaten),cx*2-20,65);	
	ctx.textAlign="start";

	if(introScreenAlpha){
		ctx.globalAlpha=introScreenAlpha;
		ctx.drawImage(startScreen,0,0,cx*2,cy*2);
		ctx.fillStyle="#0a8";
		ctx.strokeStyle="#fff";
		ctx.lineWidth=2;
		ctx.font="80px tahoma";
		ctx.fillText("HIT ENTER",cx+160,cy+325);
		ctx.strokeText("HIT ENTER",cx+160,cy+325);
		ctx.lineWidth=1;
		ctx.fillStyle="#fff";
		ctx.strokeStyle="#000";
		ctx.font="36px tahoma";
		ctx.fillText("ART: J-Robot",10,36);
		ctx.strokeText("ART: J-Robot",10,36);
		ctx.fillStyle="#00f";
		ctx.strokeStyle="#fff";
		ctx.fillText("twitter.com/J_Robotson",10,70);
		ctx.strokeText("twitter.com/J_Robotson",10,70);
		ctx.fillStyle="#fff";
		ctx.strokeStyle="#000";
		ctx.fillText("PROGRAMMING &",10,150);
		ctx.strokeText("PROGRAMMING &",10,150);
		ctx.fillText("MUSIC: cantelope",10,190);
		ctx.strokeText("MUSIC: cantelope",10,190);
		ctx.fillStyle="#00f";
		ctx.strokeStyle="#fff";
		ctx.fillText("twilightparadox.com",10,230);
		ctx.strokeText("twilightparadox.com",10,230);
	}
	if(deathScreenAlpha){
		ctx.globalAlpha=deathScreenAlpha;
		ctx.drawImage(deathScreen,0,0,cx*2,cy*2);
		ctx.fillStyle="#44f";
		ctx.strokeStyle="#fff";
		ctx.lineWidth=2;
		ctx.font="100px tahoma";
		ctx.fillText("SCORE: "+addCommas(score),cx-300,cy+120);
		ctx.strokeText("SCORE: "+addCommas(score),cx-300,cy+120);
		ctx.font="46px tahoma";
		ctx.lineWidth=1;
		ctx.fillText("HIT THE SPACEBAR",cx-210,cy+300);
		ctx.strokeText("HIT THE SPACEBAR",cx-210,cy+300);
		if(spacekey){
			score=0;
			loadLevel(false);
		}
	}
	if(victoryScreenAlpha){
		ctx.globalAlpha=victoryScreenAlpha;
		ctx.drawImage(victoryScreen,0,0,cx*2,cy*2);
		ctx.fillStyle="#ff1";
		ctx.strokeStyle="#000";
		if(level<11){
			ctx.lineWidth=2;
			ctx.font="120px tahoma";
			ctx.fillText("LEVEL COMPLETE!",cx-500,cy+150);
			ctx.strokeText("LEVEL COMPLETE!",cx-500,cy+150);		
			ctx.font="46px tahoma";
			ctx.lineWidth=1;
			ctx.fillText("HIT THE SPACEBAR",cx-210,cy+300);
			ctx.strokeText("HIT THE SPACEBAR",cx-210,cy+300);
		}else{
			ctx.lineWidth=1;
			ctx.drawImage(chuckNorris,cx-chuckNorris.width/2,320);
			ctx.fillText("*** GAME OVER ***",cx-240,cy+365);
			ctx.strokeText("*** GAME OVER ***",cx-240,cy+365);
		}
	}
}

function frame(){

	frames++;
	if(frames>10000000)frames=0;
	draw();
	if(introScreenAlpha){
		if(introScreenAlpha==1&&enterkey)introScreenAlpha-=.05;
		if(introScreenAlpha<1) introScreenAlpha-=.05;
		if(introScreenAlpha<=0)introScreenAlpha=0;
	}else{
		if(victoryScreenAlpha){
			if(victoryScreenAlpha<1){
				victoryScreenAlpha+=.05*(victoryUp?1:-1);
				if(victoryScreenAlpha>1)victoryScreenAlpha=1;
				if(victoryScreenAlpha<0)victoryScreenAlpha=0;
			}else{
				if(spacekey){
					level++;
					if(level<11){
						loadLevel(false);
						victoryScreenAlpha=.95;
						victoryUp=false;
					}
				}
			}
		}else{
			if(alive){
				doLogic();
			}else{
				if(deathScreenAlpha<1){
					deathScreenAlpha+=.05;
				}else{
					deathScreenAlpha=1;
				}
			}			
		}
	}
}

function kickoff(){
	
	loadLevel(true);
	clearInterval(loadTimer);
	$("body").css("background","#000");
	$("#canvas").show();
	introScreenAlpha=1;
	draw();
	$("#loadingOuter").hide();
	soundtrack.src="rolling.mp3";
	soundtrack.volume=.2;
	soundtrack.play();
	setInterval(frame,30);
}

function load(){

	$("#loading").html("LOADING");
	for(i=0;i<frames%4;++i) $("#loading").html($("#loading").html()+".");
	frames++;
}

loadMaps();
initVars();
loadTimer=setInterval(load,100);
$(window).load(function(){
	kickoff();
});