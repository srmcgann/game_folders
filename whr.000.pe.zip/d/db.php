<?php
  error_reporting(0);
  ini_set('upload_max_filesize', 10000000000);
  ini_set('file_uploads', 1);
  ini_set('max_input_time', 0);
  ini_set('memory_limit', -1);
  ini_set('max_execution_time', "600");
  ini_set('post_max_size', 100000000000);

  $req = ltrim($_SERVER['REQUEST_URI'],'/');
  $_GET['i'] = '';
  if(strlen($req) && !file_exists($req)){
    $_GET['i'] = $req;
  }
  if(strpos('?i=',$_GET['i'])!=false){
    $_GET['i'] = explode('?i=',$_GET['i'])[1];
  }
  //$db_user  = 'id21269596_user';
  //$db_user  = 'if0_35680402';
  //$db_user  = 'id21257390_user';
  //$db_user  = 'id21552617_user';
  //$db_user  = 'id21553412_user';
  $db_user  = 'if0_35680402';
  $db_pass  = 'nBbQv0M3POyp';
  $db_host  = 'sql200.infinityfree.com';
  //$db       = "id21269596_videodemos";
  //$db       = "if0_35680402_arena";
  //$db       = "id21257390_default";
  //$db       = "id21552617_orbs2";
  //$db       = "id21553412_orbs3";
  $db       = "if0_35680402_arena";
  $port     = '3306';
  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);
  $baseURL  = "https://whr.000.pe/d";
  

  $maxResultsPerPage = 4;
  $demoSandbox='code.twilightparadox.com/sandbox';
  $baseAssetsURL = 'https://assets.dweet.net';
  //$baseURL = 'code.twilightparadox.com';
  $baseFullURL= $baseURL;
?>


