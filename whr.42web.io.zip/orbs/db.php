<?php 
  error_reporting(E_ERROR | E_PARSE);
  //$db_user  = 'id21269596_user';
  $db_user  = 'if0_35680091';
  //$db_user  = 'id21257390_user';
  //$db_user  = 'id21552617_user';
  //$db_user  = 'id21553412_user';
  //$db_user  = 'id21583283_user';
  $db_pass  = 'kjiGQM2DqnhUAuU';
  $db_host  = 'sql312.infinityfree.com';
  //$db       = "id21269596_videodemos";
  $db       = "if0_35680091_arena";
  //$db       = "id21257390_default";
  //$db       = "id21552617_orbs2";
  //$db       = "id21553412_orbs3";
  //$db       = "id21583283_orbs4";
  $port     = '3306';
  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);
  $baseURL  = "https://whr.42web.io/delta";
?>
