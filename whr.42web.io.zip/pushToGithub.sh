#!/bin/bash
cd ..
git add .
git commit -m 'sync'
git push origin master
