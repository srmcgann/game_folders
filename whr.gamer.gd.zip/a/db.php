<?php
  error_reporting(0);
  ini_set('upload_max_filesize', 10000000000);
  ini_set('file_uploads', 1);
  ini_set('max_input_time', 0);
  ini_set('memory_limit', -1);
  ini_set('max_execution_time', "600");
  ini_set('post_max_size', 100000000000);

  $req = ltrim($_SERVER['REQUEST_URI'],'/');
  $_GET['i'] = '';
  if(strlen($req) && !file_exists($req)){
    $_GET['i'] = $req;
  }
  if(strpos('?i=',$_GET['i'])!=false){
    $_GET['i'] = explode('?i=',$_GET['i'])[1];
  }
  $db_user  = 'if0_40279886';
  $db_pass  = 'Chrome57253';
  $db_host  = 'sql101.infinityfree.com';
  $db       = "if0_40279886_arena";
  $port     = '3306';
  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);
  

  $maxResultsPerPage = 4;
  $demoSandbox='whr.gamer.gd/sandbox';
  $baseAssetsURL = 'https://assets.twilightparadox.com';
  $baseURL = 'https://whr.gamer.gd/a';
  $baseFullURL= $baseURL;
?>
