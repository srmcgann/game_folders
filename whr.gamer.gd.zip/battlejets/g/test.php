<?php
  $uri = explode('/', $_SERVER['REQUEST_URI']);
  echo sizeof($uri);
?>