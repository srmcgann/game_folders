<?php 
  error_reporting(0);
  $maxResultsPerPage = 10;
  
  
  $local = true;
  if($local){
    $baseURL='local.whr.rf.gd';
    $baseAssetsURL = 'https://local.assets.twilightparadox.com';
  }else{
    $baseURL='whr.rf.gd';
    $baseAssetsURL = 'https://assets.twilightparadox.com';
  }
  
  $req = ltrim($_SERVER['REQUEST_URI'],'/');
  $_GET['i'] = '';
  if(strlen($req) && !file_exists($req)){
    $_GET['i'] = $req;
  }
  if(strpos('?i=',$_GET['i'])!=false){
    $_GET['i'] = explode('?i=',$_GET['i'])[1];
  }


  //$db_user  = 'id21269596_user';
  //$db_user  = 'if0_35615011';
  //$db_user  = 'id21257390_user';
  //$db_user  = 'id21552617_user';
  //$db_user  = 'id21553412_user';
  $db_user  = 'if0_35615011';
  $db_pass  = 'ouVkeSu5FegeH';
  $db_host  = 'sql101.infinityfree.com';
  //$db       = "id21269596_videodemos";
  //$db       = "if0_35615011_orbs";
  //$db       = "id21257390_default";
  //$db       = "id21552617_orbs2";
  //$db       = "id21553412_orbs3";
  $db       = "if0_35615011_orbs";
  $port     = '3306';
  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);
  $baseURL  = "https://whr.rf.gd/b";
  $baseFullURL= ($local ? 'https://' : 'https://') . $baseURL;
?>
