#!/bin/bash
#./setDomainBatch.sh "whr.rf.gd" "if0_35615011" "id21284549_fishable" "Chrome57253!*" "sql101.infinityfree.com"
#mv *.zip ..
#./setDomainBatch.sh "orbs2.000webhostapp.com" "id21552617_user" "id21552617_orbs2" "Chrome57253!*" "sql101.infinityfree.com"
#mv *.zip ..
#./setDomainBatch.sh "orbs3.000webhostapp.com" "id21553412_user" "id21553412_orbs3" "Chrome57253!*" "sql101.infinityfree.com"
#mv *.zip ..
#./setDomainBatch.sh "orbs4.000webhostapp.com" "id21583283_user" "id21583283_orbs4" "Chrome57253!*" "sql101.infinityfree.com"
#mv *.zip ..
#./setDomainBatch.sh "efx2.000webhostapp.com" "id21601194_user" "id21601194_efx2" "Chrome57253!*" "sql101.infinityfree.com"
#mv *.zip ..
#./setDomainBatch.sh "efx3.000webhostapp.com" "id21601862_user" "id21601862_efx3" "Chrome57253!*" "sql101.infinityfree.com"
#mv *.zip ..
#./setDomainBatch.sh "warpspeed.000webhostapp.com" "id21607252_user" "id21607252_warpspeed" "Chrome57253!*" "sql101.infinityfree.com"
#mv *.zip ..
#./setDomainBatch.sh "orbstools.000webhostapp.com" "id21594651_user" "id21594651_orbstools" "Chrome57253!*" "sql101.infinityfree.com"
#mv *.zip ..
#./setDomainBatch.sh "gummier-fish.000webhostapp.com" "id21257390_user" "id21257390_default" "Chrome57253!*" "sql101.infinityfree.com"
mv *.zip ..
./setDomainBatch.sh "whr.rf.gd" "if0_35615011" "if0_35615011_orbs" "ouVkeSu5FegeH" "sql101.infinityfree.com"
mv *.zip ..
./setDomainBatch.sh "whr.42web.io" "if0_35680091" "if0_35680091_arena" "kjiGQM2DqnhUAuU" "sql312.infinityfree.com"
mv *.zip ..
./setDomainBatch.sh "whr.66ghz.com" "if0_35680402" "if0_35680402_arena" "nBbQv0M3POyp" "sql200.infinityfree.com"
mv *.zip ..
./setDomainBatch.sh "orb.42web.io" "if0_35680488" "if0_35680488_arena" "9K12EE4mmF3yi" "sql213.infinityfree.com"
mv *.zip ..
./setDomainBatch.sh "efx.rf.gd" "if0_35615011" "if0_35615011_orbs" "ouVkeSu5FegeH" "sql101.infinityfree.com"
mv *.zip ..
./setDomainBatch.sh "efx.42web.io" "if0_35686192" "if0_35686192_arena" "iOFWM03Om1SRTI" "sql106.infinityfree.com"
mv *.zip ..
